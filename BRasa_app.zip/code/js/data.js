// Dados do aplicativo BRasa
const appData = {
  // Usuário atual (simulado)
  currentUser: {
    id: 1,
    name: "Carlos Silva",
    email: "carlos.silva@email.com",
    phone: "(11) 99999-9999",
    photo: "https://randomuser.me/api/portraits/men/32.jpg",
    memberSince: "Jan 2025",
    badges: ["Sempre confirma", "Artilheiro"],
    teams: [1, 2]
  },
  
  // Times
  teams: [
    {
      id: 1,
      name: "Galáticos FC",
      logo: null,
      description: "Time de amigos para jogos semanais",
      players: [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
      captain: 1
    },
    {
      id: 2,
      name: "Real Amigos",
      logo: null,
      description: "Pelada de quinta à noite",
      players: [1, 14, 15, 16, 17, 18, 19, 20],
      captain: 1
    }
  ],
  
  // Jogadores
  players: [
    { id: 1, name: "Carlos Silva", photo: "https://randomuser.me/api/portraits/men/32.jpg" },
    { id: 3, name: "Marcos Oliveira", photo: "https://randomuser.me/api/portraits/men/33.jpg" },
    { id: 4, name: "Pedro Santos", photo: "https://randomuser.me/api/portraits/men/34.jpg" },
    { id: 5, name: "João Costa", photo: "https://randomuser.me/api/portraits/men/35.jpg" },
    { id: 6, name: "Lucas Ferreira", photo: "https://randomuser.me/api/portraits/men/36.jpg" },
    { id: 7, name: "Rafael Almeida", photo: "https://randomuser.me/api/portraits/men/37.jpg" },
    { id: 8, name: "André Souza", photo: "https://randomuser.me/api/portraits/men/38.jpg" },
    { id: 9, name: "Gustavo Lima", photo: "https://randomuser.me/api/portraits/men/39.jpg" },
    { id: 10, name: "Felipe Martins", photo: "https://randomuser.me/api/portraits/men/40.jpg" },
    { id: 11, name: "Bruno Cardoso", photo: "https://randomuser.me/api/portraits/men/41.jpg" },
    { id: 12, name: "Ricardo Oliveira", photo: "https://randomuser.me/api/portraits/men/42.jpg" },
    { id: 13, name: "Thiago Silva", photo: "https://randomuser.me/api/portraits/men/43.jpg" },
    { id: 14, name: "Marcelo Santos", photo: "https://randomuser.me/api/portraits/men/44.jpg" },
    { id: 15, name: "Paulo Henrique", photo: "https://randomuser.me/api/portraits/men/45.jpg" },
    { id: 16, name: "Roberto Carlos", photo: "https://randomuser.me/api/portraits/men/46.jpg" },
    { id: 17, name: "Daniel Alves", photo: "https://randomuser.me/api/portraits/men/47.jpg" },
    { id: 18, name: "Ronaldo Nazário", photo: "https://randomuser.me/api/portraits/men/48.jpg" },
    { id: 19, name: "Neymar Junior", photo: "https://randomuser.me/api/portraits/men/49.jpg" },
    { id: 20, name: "Vinícius Junior", photo: "https://randomuser.me/api/portraits/men/50.jpg" }
  ],
  
  // Amistosos
  friendlyMatches: [
    {
      id: 1,
      title: "Futsal na Arena Santos",
      type: "Futsal",
      date: "2025-04-23",
      time: "19:00",
      duration: "2h",
      location: "Arena Santos, São Paulo",
      coordinates: { lat: -23.9618, lng: -46.3322 },
      maxPlayers: 10,
      confirmedPlayers: [1, 3, 4, 5, 6, 7, 8],
      price: 25.00,
      needReferee: false,
      payments: {
        1: true, // id do jogador: status de pagamento
        3: true,
        4: false,
        5: true,
        6: false,
        7: true,
        8: true
      },
      teams: {
        teamA: [],
        teamB: []
      },
      creator: 1
    },
    {
      id: 2,
      title: "Society no Clube Atlético",
      type: "Society",
      date: "2025-04-24",
      time: "20:00",
      duration: "2h",
      location: "Clube Atlético, São Paulo",
      coordinates: { lat: -23.5505, lng: -46.6333 },
      maxPlayers: 14,
      confirmedPlayers: [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
      price: 30.00,
      needReferee: true,
      payments: {
        1: true,
        3: true,
        4: true,
        5: true,
        6: true,
        7: true,
        8: true,
        9: false,
        10: false,
        11: true,
        12: true,
        13: true
      },
      teams: {
        teamA: [],
        teamB: []
      },
      creator: 3
    },
    {
      id: 3,
      title: "Campo 7 no Parque",
      type: "Campo 7",
      date: "2025-04-26",
      time: "18:00",
      duration: "2h",
      location: "Parque do Ibirapuera, São Paulo",
      coordinates: { lat: -23.5874, lng: -46.6576 },
      maxPlayers: 14,
      confirmedPlayers: [1, 3, 4, 5, 6, 7, 8, 9, 10],
      price: 20.00,
      needReferee: false,
      payments: {
        1: true,
        3: true,
        4: false,
        5: true,
        6: true,
        7: false,
        8: true,
        9: true,
        10: false
      },
      teams: {
        teamA: [],
        teamB: []
      },
      creator: 1
    }
  ],
  
  // Campos
  venues: [
    {
      id: 1,
      name: "Arena Santos",
      address: "Rua das Palmeiras, 123 - Santos, SP",
      coordinates: { lat: -23.9618, lng: -46.3322 },
      photos: ["venue1.jpg"],
      prices: {
        "Futsal": 250.00,
        "Society": 300.00
      },
      availableHours: [
        { day: "Segunda", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Terça", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Quarta", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Quinta", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Sexta", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Sábado", hours: ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00", "18:00"] },
        { day: "Domingo", hours: ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"] }
      ],
      rating: 4.5
    },
    {
      id: 2,
      name: "Clube Atlético",
      address: "Av. Paulista, 1000 - São Paulo, SP",
      coordinates: { lat: -23.5505, lng: -46.6333 },
      photos: ["venue2.jpg"],
      prices: {
        "Society": 350.00,
        "Campo 7": 400.00
      },
      availableHours: [
        { day: "Segunda", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Terça", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Quarta", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Quinta", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Sexta", hours: ["18:00", "19:00", "20:00", "21:00"] },
        { day: "Sábado", hours: ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00", "18:00"] },
        { day: "Domingo", hours: ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"] }
      ],
      rating: 4.8
    }
  ],
  
  // Árbitros
  referees: [
    {
      id: 1,
      name: "José Pereira",
      photo: "https://randomuser.me/api/portraits/men/60.jpg",
      phone: "(11) 98888-8888",
      price: 150.00,
      rating: 4.7,
      availability: [
        { day: "Segunda", hours: ["19:00", "20:00", "21:00"] },
        { day: "Quarta", hours: ["19:00", "20:00", "21:00"] },
        { day: "Sexta", hours: ["19:00", "20:00", "21:00"] },
        { day: "Sábado", hours: ["14:00", "15:00", "16:00", "17:00", "18:00"] },
        { day: "Domingo", hours: ["10:00", "11:00", "14:00", "15:00", "16:00"] }
      ]
    },
    {
      id: 2,
      name: "Antônio Silva",
      photo: "https://randomuser.me/api/portraits/men/61.jpg",
      phone: "(11) 97777-7777",
      price: 120.00,
      rating: 4.5,
      availability: [
        { day: "Terça", hours: ["19:00", "20:00", "21:00"] },
        { day: "Quinta", hours: ["19:00", "20:00", "21:00"] },
        { day: "Sábado", hours: ["09:00", "10:00", "11:00", "14:00", "15:00"] },
        { day: "Domingo", hours: ["09:00", "10:00", "11:00", "14:00", "15:00"] }
      ]
    }
  ],
  
  // Histórico de jogos do usuário atual
  matchHistory: [
    {
      id: 101,
      title: "Futsal na Arena Santos",
      date: "2025-04-15",
      result: "Vitória (5x3)",
      team: "Time A"
    },
    {
      id: 102,
      title: "Society no Clube Atlético",
      date: "2025-04-08",
      result: "Derrota (2x4)",
      team: "Time B"
    }
  ]
};

// Funções para manipulação de dados
const dataService = {
  // Obter todos os amistosos
  getAllMatches: function() {
    return appData.friendlyMatches;
  },
  
  // Obter amistoso por ID
  getMatchById: function(id) {
    return appData.friendlyMatches.find(match => match.id === id);
  },
  
  // Obter amistosos próximos (futuros)
  getUpcomingMatches: function() {
    const today = new Date();
    return appData.friendlyMatches.filter(match => {
      const matchDate = new Date(match.date + 'T' + match.time);
      return matchDate >= today;
    }).sort((a, b) => {
      const dateA = new Date(a.date + 'T' + a.time);
      const dateB = new Date(b.date + 'T' + b.time);
      return dateA - dateB;
    });
  },
  
  // Obter jogador por ID
  getPlayerById: function(id) {
    return appData.players.find(player => player.id === id);
  },
  
  // Obter time por ID
  getTeamById: function(id) {
    return appData.teams.find(team => team.id === id);
  },
  
  // Obter jogadores de um time
  getTeamPlayers: function(teamId) {
    const team = this.getTeamById(teamId);
    if (!team) return [];
    
    return team.players.map(playerId => this.getPlayerById(playerId));
  },
  
  // Obter jogadores confirmados em um amistoso
  getConfirmedPlayers: function(matchId) {
    const match = this.getMatchById(matchId);
    if (!match) return [];
    
    return match.confirmedPlayers.map(playerId => {
      const player = this.getPlayerById(playerId);
      return {
        ...player,
        paid: match.payments[playerId] || false
      };
    });
  },
  
  // Confirmar presença em um amistoso
  confirmPresence: function(matchId, playerId) {
    const match = this.getMatchById(matchId);
    if (!match) return false;
    
    if (match.confirmedPlayers.includes(playerId)) {
      return true; // Já está confirmado
    }
    
    if (match.confirmedPlayers.length >= match.maxPlayers) {
      return false; // Amistoso lotado
    }
    
    match.confirmedPlayers.push(playerId);
    match.payments[playerId] = false; // Inicialmente não pago
    return true;
  },
  
  // Cancelar presença em um amistoso
  cancelPresence: function(matchId, playerId) {
    const match = this.getMatchById(matchId);
    if (!match) return false;
    
    const index = match.confirmedPlayers.indexOf(playerId);
    if (index === -1) {
      return false; // Não estava confirmado
    }
    
    match.confirmedPlayers.splice(index, 1);
    delete match.payments[playerId];
    return true;
  },
  
  // Registrar pagamento
  registerPayment: function(matchId, playerId) {
    const match = this.getMatchById(matchId);
    if (!match || !match.confirmedPlayers.includes(playerId)) {
      return false;
    }
    
    match.payments[playerId] = true;
    return true;
  },
  
  // Criar novo amistoso
  createMatch: function(matchData) {
    const newId = Math.max(...appData.friendlyMatches.map(m => m.id)) + 1;
    const newMatch = {
      id: newId,
      confirmedPlayers: [appData.currentUser.id], // Criador já está confirmado
      payments: {},
      teams: { teamA: [], teamB: [] },
      creator: appData.currentUser.id,
      ...matchData
    };
    
    // Inicializa o pagamento do criador como true (já pago)
    newMatch.payments[appData.currentUser.id] = true;
    
    appData.friendlyMatches.push(newMatch);
    return newMatch;
  },
  
  // Sortear times
  randomizeTeams: function(matchId) {
    const match = this.getMatchById(matchId);
    if (!match) return false;
    
    const players = [...match.confirmedPlayers];
    // Embaralhar jogadores
    for (let i = players.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [players[i], players[j]] = [players[j], players[i]];
    }
    
    const halfLength = Math.ceil(players.length / 2);
    match.teams.teamA = players.slice(0, halfLength);
    match.teams.teamB = players.slice(halfLength);
    
    return match.teams;
  },
  
  // Definir times manualmente
  setTeams: function(matchId, teamA, teamB) {
    const match = this.getMatchById(matchId);
    if (!match) return false;
    
    // Verificar se todos os jogadores estão confirmados
    const allPlayers = [...teamA, ...teamB];
    const allConfirmed = allPlayers.every(playerId => 
      match.confirmedPlayers.includes(playerId)
    );
    
    if (!allConfirmed) return false;
    
    match.teams.teamA = teamA;
    match.teams.teamB = teamB;
    return true;
  },
  
  // Criar novo time
  createTeam: function(teamData) {
    const newId = Math.max(...appData.teams.map(t => t.id)) + 1;
    const newTeam = {
      id: newId,
      players: [appData.currentUser.id], // Criador já está no time
      captain: appData.currentUser.id,
      ...teamData
    };
    
    appData.teams.push(newTeam);
    appData.currentUser.teams.push(newId);
    return newTeam;
  },
  
  // Adicionar jogador a um time
  addPlayerToTeam: function(teamId, playerId) {
    const team = this.getTeamById(teamId);
    if (!team) return false;
    
    if (team.players.includes(playerId)) {
      return true; // Jogador já está no time
    }
    
    team.players.push(playerId);
    return true;
  },
  
  // Remover jogador de um time
  removePlayerFromTeam: function(teamId, playerId) {
    const team = this.getTeamById(teamId);
    if (!team) return false;
    
    // Não pode remover o capitão
    if (team.captain === playerId) {
      return false;
    }
    
    const index = team.players.indexOf(playerId);
    if (index === -1) {
      return false; // Jogador não está no time
    }
    
    team.players.splice(index, 1);
    return true;
  }
};

// Exportar para uso global
window.appData = appData;
window.dataService = dataService;
