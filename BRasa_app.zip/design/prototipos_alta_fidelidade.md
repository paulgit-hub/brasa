# Protótipos de Alta Fidelidade - BRasa

## Visão Geral
Após a criação dos wireframes de baixa fidelidade, o próximo passo é desenvolver protótipos de alta fidelidade que representem com maior precisão a aparência final do aplicativo. Estes protótipos seguirão a paleta de cores definida e incorporarão elementos visuais mais refinados.

## Elementos de Design

### Tipografia
- **Fonte Principal**: Roboto
- **Títulos**: Roboto Bold, 18-24px
- **Subtítulos**: Roboto Medium, 16px
- **Texto Normal**: Roboto Regular, 14px
- **Texto Pequeno**: Roboto Light, 12px

### Ícones
- Conjunto de ícones Material Design
- Tamanho padrão: 24x24px
- Cores adaptadas à paleta do BRasa

### Componentes UI
- **Botões Primários**: Fundo laranja (#FF9900), texto branco, cantos arredondados (8px)
- **Botões Secundários**: Fundo verde (#006633), texto branco, cantos arredondados (8px)
- **Cards**: Fundo branco, sombra suave, cantos arredondados (10px)
- **Campos de Formulário**: Borda fina cinza, foco em verde, preenchimento interno de 12px
- **Badges**: Fundo amarelo (#FFCC00), texto preto, cantos totalmente arredondados

### Elementos Específicos
- **Botão "+"**: Círculo laranja (#FF9900), ícone branco, tamanho 60x60px, sombra pronunciada
- **Barra de Navegação**: Fundo verde (#006633), texto/ícones brancos
- **Tab Bar**: Fundo branco, ícones e texto em verde quando ativos, cinza quando inativos

## Telas em Alta Fidelidade

### Tela Inicial
- Cabeçalho verde com logo BRasa
- Lista de cards de amistosos próximos
- Cada card contém:
  - Título do amistoso
  - Data e horário
  - Local com ícone de localização
  - Número de confirmados com ícone de pessoas
  - Botão "Ver Detalhes" em laranja
- Botão "+" flutuante no canto inferior direito
- Tab bar na parte inferior com ícones para: Início, Meus Jogos, Times, Perfil

### Tela de Criação de Amistoso
- Formulário com campos para:
  - Tipo de jogo (dropdown)
  - Data e hora (seletor)
  - Local (com integração de mapa)
  - Número de jogadores
  - Valor por jogador
  - Checkbox para árbitro
- Botão "Criar Amistoso" em laranja ocupando toda a largura da tela

### Tela de Perfil
- Foto do usuário circular
- Nome e data de registro
- Badges de reputação em amarelo
- Seção "Meus Times" com cards de times
- Seção "Histórico de Jogos" com cards de partidas anteriores
- Tab bar na parte inferior

### Tela de Detalhes do Amistoso
- Card principal com informações do amistoso
- Lista de jogadores confirmados com status de pagamento
- Botões "Confirmar" e "Compartilhar" lado a lado
- Botão "Escalar Times" em verde ocupando toda a largura

### Tela de Escalação
- Botões de alternância entre "Manual" e "Sorteio"
- Duas seções: "Time A" e "Time B"
- Lista de jogadores em cada time
- Botões "Sortear Novamente" e "Confirmar Times"

### Tela de Cadastro de Time
- Área para upload de escudo do time
- Campos para nome e descrição
- Lista de jogadores com o capitão destacado
- Botões "Adicionar Jogadores" e "Salvar Time"

## Próximos Passos
- Implementar protótipos interativos usando Figma ou Adobe XD
- Testar fluxos de navegação entre telas
- Validar experiência do usuário
- Preparar assets para implementação
