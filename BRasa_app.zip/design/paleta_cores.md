# Paleta de Cores do BRasa

## Cores Principais
- **Verde Principal**: #006633
- **Amarelo Principal**: #FFCC00
- **Laranja (Destaque)**: #FF9900
- **Branco (Fundo)**: #FFFFFF
- **Preto (Texto)**: #333333

## Cores Secundárias
- **Verde Claro**: #009966
- **Verde Escuro**: #004D26
- **Amarelo Claro**: #FFDD33
- **Laranja Escuro**: #E68A00
- **Cinza Claro**: #F2F2F2
- **Cinza Médio**: #CCCCCC

## Aplicação das Cores
- **Cabeçalhos e Barras de Navegação**: Verde Principal (#006633)
- **Botões de Ação Principal**: Laranja (#FF9900)
- **Botões Secundários**: Verde Claro (#009966)
- **Destaques e Badges**: Amarelo Principal (#FFCC00)
- **Fundo de Telas**: Branco (#FFFFFF) ou Cinza Claro (#F2F2F2)
- **Texto Principal**: Preto (#333333)
- **Texto em Fundos Escuros**: Branco (#FFFFFF)
- **Bordas e Separadores**: Cinza Médio (#CCCCCC)

## Gradientes
- **Gradiente Principal**: Verde Principal (#006633) para Verde Claro (#009966)
- **Gradiente de Destaque**: Amarelo Principal (#FFCC00) para Laranja (#FF9900)
