// Inicialização do aplicativo BRasa

// Função para inicializar o aplicativo
function initApp() {
  // Verificar se o DOM está pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApp);
  } else {
    startApp();
  }
}

// Função para iniciar o aplicativo
function startApp() {
  // Inicializar controladores
  controllers.init();
  
  // Registrar service worker para funcionalidades offline (simulado)
  if ('serviceWorker' in navigator) {
    console.log('Service Worker suportado, mas não implementado neste protótipo');
  }
}

// Iniciar o aplicativo
initApp();
