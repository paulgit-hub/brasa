# Requisitos do Aplicativo BRasa

## 1. Conceito do App
Um aplicativo 100% focado em amistosos de futebol (peladas/rachas/amistosos/ligas), sem burocracia, onde qualquer pessoa pode marcar jogos, convidar times, gerenciar escalação e até arbitragem.

## 2. Funcionalidades Principais

### Para Jogadores/Organizadores
- **Criar Amistosos**:
  - Data/horário, local (integração com Google Maps)
  - Tipo de jogo (futsal, society, campo 7, etc.)
  - Definir número de jogadores
  - Opção para requisitar árbitro
  - Configurar valor por jogador (se houver)

- **Times & Convidados**:
  - Cadastrar times (nome, escudo, jogadores fixos)
  - Convidar times ou jogadores avulsos (por link WhatsApp/Telegram)

- **Escalação & Confirmação**:
  - Lista de confirmados (com opção "vou +1")
  - Sortear times na hora ou escalar manualmente
  - Sugestão de divisão equilibrada de times

- **Pagamentos (opcional)**:
  - Rateio automático (integração com PicPay, Mercado Pago)
  - Marcação de quem já pagou

### Para Campos/Árbitros
- **Cadastro de Campos**:
  - Donos de campo podem listar horários disponíveis e preços

- **Árbitros Disponíveis**:
  - Juízes podem se cadastrar e ser contratados diretamente pelo app

## 3. Interface "Enjunta" (Simples e Objetiva)
- **Tela Inicial**: Lista de peladas próximas (com filtro por dia/esporte/local)
- **Botão "+" grande** no meio da tela para criar amistoso em 2 cliques
- **Perfil**: Histórico de jogos, times que participa, reputação (ex.: "Sempre confirma")

## 4. Esquema de Cores
- Verde e amarelo como cores principais (conforme imagem de referência)
- Elementos em laranja para destaque
- Fundo branco para áreas de conteúdo
