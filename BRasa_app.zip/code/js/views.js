// Componentes de visualização do aplicativo BRasa

const views = {
  // Renderiza o layout básico do aplicativo
  renderLayout: function() {
    return `
      <div class="app-container">
        <div id="page-content"></div>
        <div class="bottom-nav">
          <div class="nav-item" data-page="home">
            <i class="nav-icon fas fa-home"></i>
            <div class="nav-text">Início</div>
          </div>
          <div class="nav-item" data-page="my-matches">
            <i class="nav-icon fas fa-futbol"></i>
            <div class="nav-text">Meus Jogos</div>
          </div>
          <div class="nav-item" data-page="teams">
            <i class="nav-icon fas fa-users"></i>
            <div class="nav-text">Times</div>
          </div>
          <div class="nav-item" data-page="profile">
            <i class="nav-icon fas fa-user"></i>
            <div class="nav-text">Perfil</div>
          </div>
        </div>
        <div class="btn-float" id="create-match-btn">+</div>
      </div>
    `;
  },
  
  // Página inicial - Lista de amistosos próximos
  renderHomePage: function() {
    const upcomingMatches = dataService.getUpcomingMatches();
    
    let matchesHtml = '';
    upcomingMatches.forEach(match => {
      const confirmedCount = match.confirmedPlayers.length;
      const maxPlayers = match.maxPlayers;
      
      // Formatar data para exibição
      const matchDate = new Date(match.date + 'T' + match.time);
      const today = new Date();
      const tomorrow = new Date();
      tomorrow.setDate(today.getDate() + 1);
      
      let dateDisplay = '';
      if (matchDate.toDateString() === today.toDateString()) {
        dateDisplay = 'Hoje';
      } else if (matchDate.toDateString() === tomorrow.toDateString()) {
        dateDisplay = 'Amanhã';
      } else {
        const options = { weekday: 'long' };
        dateDisplay = matchDate.toLocaleDateString('pt-BR', options);
        // Capitalize first letter
        dateDisplay = dateDisplay.charAt(0).toUpperCase() + dateDisplay.slice(1);
      }
      
      matchesHtml += `
        <div class="card" data-match-id="${match.id}">
          <div class="card-title">${match.title}</div>
          <p><i class="fas fa-calendar"></i> ${dateDisplay}, ${match.time} - ${match.duration}</p>
          <p><i class="fas fa-map-marker-alt"></i> ${match.location}</p>
          <p><i class="fas fa-users"></i> ${confirmedCount}/${maxPlayers} confirmados</p>
          <button class="btn btn-primary view-match-btn" data-match-id="${match.id}">Ver Detalhes</button>
        </div>
      `;
    });
    
    if (matchesHtml === '') {
      matchesHtml = '<p>Nenhum amistoso próximo encontrado.</p>';
    }
    
    return `
      <div class="header">
        <div class="menu-icon"><i class="fas fa-bars"></i></div>
        <div class="logo">BRasa</div>
        <div class="search-icon"><i class="fas fa-search"></i></div>
      </div>
      <div class="content">
        <h3>Peladas Próximas</h3>
        ${matchesHtml}
      </div>
    `;
  },
  
  // Página de detalhes do amistoso
  renderMatchDetails: function(matchId) {
    const match = dataService.getMatchById(matchId);
    if (!match) {
      return '<div class="content"><p>Amistoso não encontrado.</p></div>';
    }
    
    const confirmedPlayers = dataService.getConfirmedPlayers(matchId);
    const confirmedCount = confirmedPlayers.length;
    const maxPlayers = match.maxPlayers;
    
    // Formatar data para exibição
    const matchDate = new Date(match.date + 'T' + match.time);
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    
    let dateDisplay = '';
    if (matchDate.toDateString() === today.toDateString()) {
      dateDisplay = 'Hoje';
    } else if (matchDate.toDateString() === tomorrow.toDateString()) {
      dateDisplay = 'Amanhã';
    } else {
      const options = { weekday: 'long', day: 'numeric', month: 'long' };
      dateDisplay = matchDate.toLocaleDateString('pt-BR', options);
      // Capitalize first letter
      dateDisplay = dateDisplay.charAt(0).toUpperCase() + dateDisplay.slice(1);
    }
    
    // Lista de jogadores confirmados
    let playersHtml = '';
    confirmedPlayers.forEach(player => {
      const paidStatus = player.paid 
        ? '<span class="status-paid"><i class="fas fa-check"></i> Pago</span>' 
        : '<span class="status-pending"><i class="fas fa-times"></i> Pendente</span>';
      
      playersHtml += `
        <div class="list-item">
          <div>${player.name}</div>
          <div>${paidStatus}</div>
        </div>
      `;
    });
    
    // Verificar se o usuário atual já está confirmado
    const isUserConfirmed = match.confirmedPlayers.includes(appData.currentUser.id);
    const confirmBtnText = isUserConfirmed ? 'Cancelar Presença' : 'Confirmar Presença';
    const confirmBtnClass = isUserConfirmed ? 'btn-secondary' : 'btn-primary';
    
    // Verificar se os times já foram escalados
    const teamsEscalated = match.teams.teamA.length > 0 || match.teams.teamB.length > 0;
    
    return `
      <div class="header">
        <div class="back-icon"><i class="fas fa-arrow-left"></i></div>
        <div class="logo">Detalhes</div>
        <div class="options-icon"><i class="fas fa-ellipsis-v"></i></div>
      </div>
      <div class="content">
        <div class="card">
          <div class="card-title">${match.title}</div>
          <p><i class="fas fa-calendar"></i> ${dateDisplay}, ${match.time} - ${match.duration}</p>
          <p><i class="fas fa-map-marker-alt"></i> ${match.location}</p>
          <p><i class="fas fa-users"></i> ${confirmedCount}/${maxPlayers} confirmados</p>
          <p><i class="fas fa-money-bill-wave"></i> R$ ${match.price.toFixed(2)} por jogador</p>
        </div>
        
        <h3>Jogadores Confirmados</h3>
        <div class="card">
          ${playersHtml}
        </div>
        
        <div style="display: flex; justify-content: space-between; margin-top: 20px;">
          <button class="btn ${confirmBtnClass}" id="confirm-presence-btn" data-match-id="${match.id}">${confirmBtnText}</button>
          <button class="btn btn-secondary" id="share-match-btn" data-match-id="${match.id}">Compartilhar</button>
        </div>
        
        <button class="btn btn-secondary btn-full" style="margin-top: 20px;" id="escalate-teams-btn" data-match-id="${match.id}">${teamsEscalated ? 'Ver Times' : 'Escalar Times'}</button>
      </div>
    `;
  },
  
  // Página de criação de amistoso
  renderCreateMatch: function() {
    return `
      <div class="header">
        <div class="back-icon"><i class="fas fa-arrow-left"></i></div>
        <div class="logo">Novo Amistoso</div>
        <div></div>
      </div>
      <div class="content">
        <form id="create-match-form">
          <div class="form-group">
            <label class="form-label">Título</label>
            <input type="text" class="form-input" id="match-title" placeholder="Ex: Futsal na Arena Santos" required>
          </div>
          
          <div class="form-group">
            <label class="form-label">Tipo de Jogo</label>
            <select class="form-input" id="match-type" required>
              <option value="">Selecione o tipo</option>
              <option value="Futsal">Futsal</option>
              <option value="Society">Society</option>
              <option value="Campo 7">Campo 7</option>
              <option value="Campo 11">Campo 11</option>
            </select>
          </div>
          
          <div class="form-group">
            <label class="form-label">Data</label>
            <input type="date" class="form-input" id="match-date" required>
          </div>
          
          <div class="form-group">
            <label class="form-label">Hora</label>
            <input type="time" class="form-input" id="match-time" required>
          </div>
          
          <div class="form-group">
            <label class="form-label">Duração</label>
            <select class="form-input" id="match-duration" required>
              <option value="1h">1 hora</option>
              <option value="1h30">1 hora e 30 minutos</option>
              <option value="2h" selected>2 horas</option>
              <option value="2h30">2 horas e 30 minutos</option>
              <option value="3h">3 horas</option>
            </select>
          </div>
          
          <div class="form-group">
            <label class="form-label">Local</label>
            <input type="text" class="form-input" id="match-location" placeholder="Buscar local..." required>
            <div style="background-color: #ccc; height: 120px; margin-top: 10px; border-radius: 5px; display: flex; justify-content: center; align-items: center;">
              Mapa
            </div>
          </div>
          
          <div class="form-group">
            <label class="form-label">Número de Jogadores</label>
            <input type="number" class="form-input" id="match-max-players" min="4" max="22" value="10" required>
          </div>
          
          <div class="form-group">
            <label class="form-label">Valor por Jogador (R$)</label>
            <input type="number" class="form-input" id="match-price" min="0" step="0.01" placeholder="25.00" required>
          </div>
          
          <div class="form-group">
            <input type="checkbox" id="match-referee">
            <label for="match-referee">Precisa de árbitro</label>
          </div>
          
          <button type="submit" class="btn btn-primary btn-full">Criar Amistoso</button>
        </form>
      </div>
    `;
  },
  
  // Página de escalação de times
  renderTeamEscalation: function(matchId) {
    const match = dataService.getMatchById(matchId);
    if (!match) {
      return '<div class="content"><p>Amistoso não encontrado.</p></div>';
    }
    
    const confirmedPlayers = dataService.getConfirmedPlayers(matchId);
    
    // Verificar se os times já foram escalados
    const teamsEscalated = match.teams.teamA.length > 0 || match.teams.teamB.length > 0;
    
    // Renderizar jogadores do Time A
    let teamAHtml = '';
    if (teamsEscalated) {
      match.teams.teamA.forEach(playerId => {
        const player = dataService.getPlayerById(playerId);
        if (player) {
          teamAHtml += `<div>${player.name}</div>`;
        }
      });
    }
    
    // Renderizar jogadores do Time B
    let teamBHtml = '';
    if (teamsEscalated) {
      match.teams.teamB.forEach(playerId => {
        const player = dataService.getPlayerById(playerId);
        if (player) {
          teamBHtml += `<div>${player.name}</div>`;
        }
      });
    }
    
    return `
      <div class="header">
        <div class="back-icon"><i class="fas fa-arrow-left"></i></div>
        <div class="logo">Escalação</div>
        <div></div>
      </div>
      <div class="content">
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
          <button class="btn btn-primary" id="manual-escalation-btn">Manual</button>
          <button class="btn btn-secondary" id="random-escalation-btn" data-match-id="${match.id}">Sorteio</button>
        </div>
        
        <h3>Time A</h3>
        <div class="card">
          ${teamAHtml || 'Nenhum jogador escalado'}
        </div>
        
        <h3>Time B</h3>
        <div class="card">
          ${teamBHtml || 'Nenhum jogador escalado'}
        </div>
        
        ${teamsEscalated ? `
          <button class="btn btn-primary btn-full" style="margin-top: 20px;" id="randomize-again-btn" data-match-id="${match.id}">Sortear Novamente</button>
        ` : ''}
        
        <button class="btn btn-secondary btn-full" style="margin-top: 10px;" id="confirm-teams-btn" data-match-id="${match.id}">Confirmar Times</button>
      </div>
    `;
  },
  
  // Página de perfil do usuário
  renderProfile: function() {
    const user = appData.currentUser;
    
    // Renderizar badges
    let badgesHtml = '';
    user.badges.forEach(badge => {
      badgesHtml += `<span class="badge">${badge}</span>`;
    });
    
    // Renderizar times do usuário
    let teamsHtml = '';
    user.teams.forEach(teamId => {
      const team = dataService.getTeamById(teamId);
      if (team) {
        const playerCount = team.players.length;
        teamsHtml += `
          <div class="card" data-team-id="${team.id}">
            <div class="card-title">${team.name}</div>
            <p><i class="fas fa-users"></i> ${playerCount} jogadores</p>
          </div>
        `;
      }
    });
    
    if (teamsHtml === '') {
      teamsHtml = '<p>Você ainda não participa de nenhum time.</p>';
    }
    
    // Renderizar histórico de jogos
    let historyHtml = '';
    appData.matchHistory.forEach(match => {
      historyHtml += `
        <div class="card">
          <div class="card-title">${match.title}</div>
          <p><i class="fas fa-calendar"></i> ${match.date}</p>
          <p><i class="fas fa-trophy"></i> Resultado: ${match.result}</p>
        </div>
      `;
    });
    
    if (historyHtml === '') {
      historyHtml = '<p>Nenhum jogo no histórico.</p>';
    }
    
    return `
      <div class="header">
        <div class="back-icon"><i class="fas fa-arrow-left"></i></div>
        <div class="logo">Perfil</div>
        <div class="settings-icon"><i class="fas fa-cog"></i></div>
      </div>
      <div class="content">
        <div class="profile-header">
          <div class="profile-pic">
            <img src="${user.photo}" alt="${user.name}" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div class="profile-info">
            <div class="profile-name">${user.name}</div>
            <div>Membro desde: ${user.memberSince}</div>
            <div>
              ${badgesHtml}
            </div>
          </div>
        </div>
        
        <h3>Meus Times</h3>
        ${teamsHtml}
        <button class="btn btn-primary btn-full" id="create-team-btn">Criar Novo Time</button>
        
        <h3>Histórico de Jogos</h3>
        ${historyHtml}
      </div>
    `;
  },
  
  // Página de times
  renderTeams: function() {
    const user = appData.currentUser;
    
    // Renderizar times do usuário
    let teamsHtml = '';
    user.teams.forEach(teamId => {
      const team = dataService.getTeamById(teamId);
      if (team) {
        const playerCount = team.players.length;
        teamsHtml += `
          <div class="card" data-team-id="${team.id}">
            <div class="card-title">${team.name}</div>
            <p><i class="fas fa-users"></i> ${playerCount} jogadores</p>
            <button class="btn btn-primary view-team-btn" data-team-id="${team.id}">Ver Time</button>
          </div>
        `;
      }
    });
    
    if (teamsHtml === '') {
      teamsHtml = '<p>Você ainda não participa de nenhum time.</p>';
    }
    
    return `
      <div class="header">
        <div class="menu-icon"><i class="fas fa-bars"></i></div>
        <div class="logo">Meus Times</div>
        <div></div>
      </div>
      <div class="content">
        ${teamsHtml}
        <button class="btn btn-primary btn-full" id="create-team-btn">Criar Novo Time</button>
      </div>
    `;
  },
  
  // Página de criação de time
  renderCreateTeam: function() {
    return `
      <div class="header">
        <div class="back-icon"><i class="fas fa-arrow-left"></i></div>
        <div class="logo">Novo Time</div>
        <div></div>
      </div>
      <div class="content">
        <div style="width: 100px; height: 100px; background-color: #ccc; border-radius: 50%; margin: 0 auto 20px; display: flex; justify-content: center; align-items: center;">
          Escudo
        </div>
        
        <form id="create-team-form">
          <div class="form-group">
            <label class="form-label">Nome do Time</label>
            <input type="text" class="form-input" id="team-name" placeholder="Ex: Galáticos FC" required>
          </div>
          
          <div class="form-group">
            <label class="form-label">Descrição (opcional)</label>
            <textarea class="form-input" id="team-description" rows="3" placeholder="Breve descrição do time..."></textarea>
          </div>
          
          <h3>Jogadores</h3>
          <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>${appData.currentUser.name} (você)</div>
              <div>Capitão</div>
            </div>
          </div>
          
          <button type="button" class="btn btn-primary btn-full" style="margin-top: 20px;" id="add-players-btn">Adicionar Jogadores</button>
          <button type="submit" class="btn btn-secondary btn-full" style="margin-top: 10px;">Salvar Time</button>
        </form>
      </div>
    `;
  },
  
  // Página de meus jogos
  renderMyMatches: function() {
    const upcomingMatches = dataService.getUpcomingMatches().filter(match => 
      match.confirmedPlayers.includes(appData.currentUser.id)
    );
    
    let matchesHtml = '';
    upcomingMatches.forEach(match => {
      const confirmedCount = match.confirmedPlayers.length;
      const maxPlayers = match.maxPlayers;
      
      // Formatar data para exibição
      const matchDate = new Date(match.date + 'T' + match.time);
      const today = new Date();
      const tomorrow = new Date();
      tomorrow.setDate(today.getDate() + 1);
      
      let dateDisplay = '';
      if (matchDate.toDateString() === today.toDateString()) {
        dateDisplay = 'Hoje';
      } else if (matchDate.toDateString() === tomorrow.toDateString()) {
        dateDisplay = 'Amanhã';
      } else {
        const options = { weekday: 'long' };
        dateDisplay = matchDate.toLocaleDateString('pt-BR', options);
        // Capitalize first letter
        dateDisplay = dateDisplay.charAt(0).toUpperCase() + dateDisplay.slice(1);
      }
      
      matchesHtml += `
        <div class="card" data-match-id="${match.id}">
          <div class="card-title">${match.title}</div>
          <p><i class="fas fa-calendar"></i> ${dateDisplay}, ${match.time} - ${match.duration}</p>
          <p><i class="fas fa-map-marker-alt"></i> ${match.location}</p>
          <p><i class="fas fa-users"></i> ${confirmedCount}/${maxPlayers} confirmados</p>
          <button class="btn btn-primary view-match-btn" data-match-id="${match.id}">Ver Detalhes</button>
        </div>
      `;
    });
    
    if (matchesHtml === '') {
      matchesHtml = '<p>Você não tem jogos confirmados.</p>';
    }
    
    return `
      <div class="header">
        <div class="menu-icon"><i class="fas fa-bars"></i></div>
        <div class="logo">Meus Jogos</div>
        <div></div>
      </div>
      <div class="content">
        <h3>Jogos Confirmados</h3>
        ${matchesHtml}
      </div>
    `;
  }
};

// Exportar para uso global
window.views = views;
