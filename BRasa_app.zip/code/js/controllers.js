// Controladores do aplicativo BRasa

const controllers = {
  // Inicializa o aplicativo
  init: function() {
    // Renderiza o layout básico
    document.getElementById('app').innerHTML = views.renderLayout();
    
    // Renderiza a página inicial por padrão
    this.navigateTo('home');
    
    // Adiciona listeners para navegação
    this.setupEventListeners();
  },
  
  // Configura os event listeners
  setupEventListeners: function() {
    // Navegação inferior
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        const page = e.currentTarget.dataset.page;
        this.navigateTo(page);
      });
    });
    
    // Botão de criar amistoso
    document.getElementById('create-match-btn').addEventListener('click', () => {
      this.navigateTo('create-match');
    });
    
    // Delegação de eventos para o conteúdo dinâmico
    document.getElementById('page-content').addEventListener('click', (e) => {
      // Botão de voltar
      if (e.target.closest('.back-icon')) {
        window.history.back();
      }
      
      // Ver detalhes do amistoso
      if (e.target.closest('.view-match-btn')) {
        const matchId = parseInt(e.target.closest('.view-match-btn').dataset.matchId);
        this.navigateTo('match-details', { matchId });
      }
      
      // Confirmar presença
      if (e.target.closest('#confirm-presence-btn')) {
        const matchId = parseInt(e.target.closest('#confirm-presence-btn').dataset.matchId);
        this.togglePresence(matchId);
      }
      
      // Compartilhar amistoso
      if (e.target.closest('#share-match-btn')) {
        const matchId = parseInt(e.target.closest('#share-match-btn').dataset.matchId);
        this.shareMatch(matchId);
      }
      
      // Escalar times
      if (e.target.closest('#escalate-teams-btn')) {
        const matchId = parseInt(e.target.closest('#escalate-teams-btn').dataset.matchId);
        this.navigateTo('team-escalation', { matchId });
      }
      
      // Sorteio de times
      if (e.target.closest('#random-escalation-btn')) {
        const matchId = parseInt(e.target.closest('#random-escalation-btn').dataset.matchId);
        this.randomizeTeams(matchId);
      }
      
      // Sortear novamente
      if (e.target.closest('#randomize-again-btn')) {
        const matchId = parseInt(e.target.closest('#randomize-again-btn').dataset.matchId);
        this.randomizeTeams(matchId);
      }
      
      // Criar time
      if (e.target.closest('#create-team-btn')) {
        this.navigateTo('create-team');
      }
      
      // Ver time
      if (e.target.closest('.view-team-btn')) {
        const teamId = parseInt(e.target.closest('.view-team-btn').dataset.teamId);
        this.viewTeam(teamId);
      }
    });
    
    // Formulário de criação de amistoso
    document.addEventListener('submit', (e) => {
      if (e.target.id === 'create-match-form') {
        e.preventDefault();
        this.createMatch();
      }
      
      if (e.target.id === 'create-team-form') {
        e.preventDefault();
        this.createTeam();
      }
    });
  },
  
  // Navegação entre páginas
  navigateTo: function(page, params = {}) {
    // Atualiza a classe ativa na navegação inferior
    document.querySelectorAll('.nav-item').forEach(item => {
      if (item.dataset.page === page) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });
    
    // Renderiza a página correspondente
    let content = '';
    switch (page) {
      case 'home':
        content = views.renderHomePage();
        break;
      case 'my-matches':
        content = views.renderMyMatches();
        break;
      case 'teams':
        content = views.renderTeams();
        break;
      case 'profile':
        content = views.renderProfile();
        break;
      case 'match-details':
        content = views.renderMatchDetails(params.matchId);
        break;
      case 'create-match':
        content = views.renderCreateMatch();
        break;
      case 'team-escalation':
        content = views.renderTeamEscalation(params.matchId);
        break;
      case 'create-team':
        content = views.renderCreateTeam();
        break;
      default:
        content = views.renderHomePage();
    }
    
    document.getElementById('page-content').innerHTML = content;
    
    // Mostrar/esconder botão flutuante em certas páginas
    const floatBtn = document.getElementById('create-match-btn');
    if (page === 'create-match' || page === 'match-details' || page === 'team-escalation' || page === 'create-team') {
      floatBtn.style.display = 'none';
    } else {
      floatBtn.style.display = 'flex';
    }
  },
  
  // Alternar confirmação de presença
  togglePresence: function(matchId) {
    const match = dataService.getMatchById(matchId);
    const userId = appData.currentUser.id;
    
    if (!match) return;
    
    const isConfirmed = match.confirmedPlayers.includes(userId);
    let success;
    
    if (isConfirmed) {
      success = dataService.cancelPresence(matchId, userId);
      if (success) {
        alert('Presença cancelada com sucesso!');
      }
    } else {
      success = dataService.confirmPresence(matchId, userId);
      if (success) {
        alert('Presença confirmada com sucesso!');
      } else {
        alert('Não foi possível confirmar presença. O amistoso pode estar lotado.');
      }
    }
    
    // Atualiza a página
    if (success) {
      this.navigateTo('match-details', { matchId });
    }
  },
  
  // Compartilhar amistoso
  shareMatch: function(matchId) {
    const match = dataService.getMatchById(matchId);
    if (!match) return;
    
    alert(`Link para compartilhar: https://brasa.app/match/${matchId}\n\nEste link pode ser enviado por WhatsApp ou Telegram.`);
  },
  
  // Sortear times
  randomizeTeams: function(matchId) {
    const teams = dataService.randomizeTeams(matchId);
    if (!teams) {
      alert('Não foi possível sortear os times.');
      return;
    }
    
    // Atualiza a página
    this.navigateTo('team-escalation', { matchId });
  },
  
  // Criar novo amistoso
  createMatch: function() {
    const title = document.getElementById('match-title').value;
    const type = document.getElementById('match-type').value;
    const date = document.getElementById('match-date').value;
    const time = document.getElementById('match-time').value;
    const duration = document.getElementById('match-duration').value;
    const location = document.getElementById('match-location').value;
    const maxPlayers = parseInt(document.getElementById('match-max-players').value);
    const price = parseFloat(document.getElementById('match-price').value);
    const needReferee = document.getElementById('match-referee').checked;
    
    // Validação básica
    if (!title || !type || !date || !time || !location || isNaN(maxPlayers) || isNaN(price)) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }
    
    // Criar o amistoso
    const newMatch = dataService.createMatch({
      title,
      type,
      date,
      time,
      duration,
      location,
      coordinates: { lat: 0, lng: 0 }, // Simulado
      maxPlayers,
      price,
      needReferee
    });
    
    if (newMatch) {
      alert('Amistoso criado com sucesso!');
      this.navigateTo('match-details', { matchId: newMatch.id });
    } else {
      alert('Erro ao criar amistoso.');
    }
  },
  
  // Criar novo time
  createTeam: function() {
    const name = document.getElementById('team-name').value;
    const description = document.getElementById('team-description').value;
    
    // Validação básica
    if (!name) {
      alert('Por favor, informe o nome do time.');
      return;
    }
    
    // Criar o time
    const newTeam = dataService.createTeam({
      name,
      description,
      logo: null // Simulado
    });
    
    if (newTeam) {
      alert('Time criado com sucesso!');
      this.navigateTo('teams');
    } else {
      alert('Erro ao criar time.');
    }
  },
  
  // Visualizar time
  viewTeam: function(teamId) {
    alert('Funcionalidade de visualização de time será implementada em breve.');
  }
};

// Inicializar o aplicativo quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
  controllers.init();
});

// Exportar para uso global
window.controllers = controllers;
